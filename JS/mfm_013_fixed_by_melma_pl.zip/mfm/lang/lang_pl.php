<?php
// ENGLISH
// for version 0.13

$lng['delete'] = 'Usuń';
$lng['delete_title'] = 'Usuń plik';

$lng['refresh'] = 'Odśwież';
$lng['refresh_files_title'] = 'Odśwież listę plików';
$lng['refresh_tree_title'] = 'Odśwież drzewo katalogów';

$lng['new_folder'] = 'Nowy folder';
$lng['new_folder_title'] = 'Utwórz nowy folder';
$lng['delete_folder'] = 'Usuń folder';
$lng['delete_folder_title'] = 'Usuń bieżący folder';
$lng['default_folder'] = 'nowy_folder';

$lng['new_file'] = 'Dodaj plik';
$lng['new_file_title'] = 'Pobierz plik z dysku';
$lng['new_file_manipulations'] = 'Edycja obrazka';

$lng['form_file'] = 'Plik:';
$lng['form_width'] = 'Zmień szerokość na:';
$lng['form_rotate'] = 'Obrót obrazka:';
$lng['form_greyscale'] = 'konwertuj do odcieni szarości';
$lng['form_submit'] = 'Załaduj';

$lng['message_created_folder'] = ' - folder utworzony!'; //(after folder name)
$lng['message_cannot_create'] = 'Nie można utworzyć folderu '; //(before folder name)
$lng['message_cannot_write'] = 'Sprawdź, czy masz uprawnienia do tworzenia folderów!';
$lng['message_exists'] = 'Folder istnieje!';
$lng['message_cannot_delete_nonexist'] = 'Nie można usunąć pliku. Plik nie znaleziony!';
$lng['message_cannot_delete'] = 'Nie można usunąć pliku!';
$lng['message_deleted'] = 'Plik usunięty!';
$lng['message_uploaded'] = 'Plik przesłany pomyślnie!';
$lng['message_upload_failed'] = 'Błąd: nie można przesłać pliku :(';
$lng['message_wrong_dir'] = 'Błąd: folder docelowy nie istnieje!';
$lng['message_folder_deleted'] = 'Folder usunięty!';
$lng['message_cant_delete_folder'] = 'Błąd: nie można usunąć folderu!';
$lng['message_folder_not_exist'] = 'Błąd: nie ma takiego folderu!';

$lng['ask_folder_title'] = 'Nazwa nowego folderu:';
$lng['ask_really_delete'] = 'Jesteś pewien?';

$lng['loading'] = 'Ładuję...';

$lng['window_title'] = 'Manager plików';
?>
