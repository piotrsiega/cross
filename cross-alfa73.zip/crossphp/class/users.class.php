<?php

/**
 * @author 
 * @copyright 2018
 */

class users{
    
    private $login,
            $passwd,
            $userQuery,
            $user,
            $con;
            
    public $logged = [];


/**
    * Funkcja łączy się z bazą danych użytkowników, próbuje pobrać  z bazy podaną 
    * w parametrze nazwę logowania, oraz weryfikuje hasło. Jeśli wszystko pójdzie
    * poprawnie, zwraca tablicę z nazwą zalogowanego użytkownika oraz informacją
    * czy jest on superużytkownikiem. Jeśli coś się ine zgadza zwraca 0 
    *  
*/    
    public function loginPasswdVerify($LOGIN,$PASSWD){
        $this->login = $LOGIN;
        $this->passwd = $PASSWD;
        
        $this->con = new db(DB_SRV,DB_USER,DB_PWD,DB_DB);
        $this->userQuery = $this->con->db->prepare('SELECT * FROM users WHERE `login` = :login');
        $this->userQuery->bindValue(':login', $this->login, PDO::PARAM_STR);
        $this->userQuery->execute();
        
        if($this->userQuery->rowCount() == 1){
            $this->user = $this->userQuery->fetch();
            if(password_verify($this->passwd,$this->user['password'])){
                $this->logged['login'] = $this->user['login'];
                $this->logged['su'] = $this->user['su'] == 1 ? 1 : '';
                return $this->logged;        
            } else {
                return 0;
                exit;
            }
        } else {
            return 0;
            exit;
        }
    }
}

?>